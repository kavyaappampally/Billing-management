#include <stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#include <ctype.h>
#include "billing.h"


void addRecord(){
	char phoneNumber[11],name[64],billAmount[10];
	int validationResult=0;// used to print the error message if required!
	//below block for taking phone number as input
	do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter 10 digit Phone Number:");
		scanf("%s",&phoneNumber);
		validationResult+=1;
	}while(validate(0,phoneNumber));
	//below block for taking name as input
	validationResult=0;
	do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter name:");
		scanf("%s",&name);
		validationResult+=1;
	}while(validate(1,name));
	// below block for taking billing amount as input
	validationResult=0;
	do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter billAmount:");
		scanf("%s",&billAmount);
		validationResult+=1;
	}while(validate(2,billAmount));
    if(checkPreexistingRecord(phoneNumber)>0){
        printf("Record Already exits!");
        return;
    }
	addRecordToFile(phoneNumber,name,billAmount);
}

void addRecordToFile(char phoneNumber[],char name[],char billAmount[]){
	FILE *fp =fopen("file.txt" , "a");

	fputs(phoneNumber, fp);
	fputs(",",fp);
	fputs(name, fp);
	fputs(",",fp);
	fputs(billAmount, fp);
	fputs("\n",fp);
	printf("Added Record Successfully\n");
	fclose(fp);
}

//Modify the records by taking phone number name and bill amount as input
void modifyRecord(){
    char phoneNumber[11],name[64],billAmount[10];
	int validationResult=0;// used to print the error message if required!
	//below block for taking phone number as input
	do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter 10 digit Phone Number:");
		scanf("%s",&phoneNumber);
		validationResult+=1;
	}while(validate(0,phoneNumber));

	//below block for taking name as input
	validationResult=0;
	do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter name:");
		scanf("%s",&name);
		validationResult+=1;
	}while(validate(1,name));

	// below block for taking billing amount as input
	validationResult=0;
	do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter billAmount:");
		scanf("%s",&billAmount);
		validationResult+=1;
	}while(validate(2,billAmount));
     modifyRecordHandler(phoneNumber, name,billAmount);
}
void modifyRecordHandler(char phoneNumber[], char name[],char billAmount[]){
    int record=0;
    if((record = checkPreexistingRecord(phoneNumber))>0){
        int linecount=0;
        FILE *ft1 = fopen("file.txt" , "r");
        FILE *ft2 = fopen("tempo.txt" , "w");
        while(linecount != record-1){
            char ch= fgetc(ft1);
            if(ch == '\n'){
                linecount+=1;
            }
            fputc(ch, ft2);
        }
        fputs(phoneNumber, ft2);
        fputs(",",ft2);
        fputs(name, ft2);
        fputs(",",ft2);
        fputs(billAmount, ft2);
        fputs("\n",ft2);
        char ch;
        while(ch != '\n'){
            ch = fgetc(ft1);
        }
        ch = fgetc(ft1);
        while(ch != EOF){
            fputc(ch, ft2);
            ch= fgetc(ft1);
        }
        fclose(ft1);
        fclose(ft2);
        ft1 = fopen("file.txt" , "w");
        ft2 = fopen("tempo.txt" , "r");
        ch = fgetc(ft2);
        while(ch != EOF){
            fputc(ch, ft1);
            ch= fgetc(ft2);
        }
        fclose(ft1);
        fclose(ft2);
        return ;
    }
    else{
        printf("No record found with that mobile number!\n\n Please check the entry!");
    }
}
// take phone number as input and check it is present in the database
int checkPreexistingRecord(char phoneNumber[]){
	char c;
	FILE *fp =fopen("file.txt" , "r");
	if ( fp == NULL )
	{
		return 0;
	}
	char phoneBookNumber[11];
	fp =fopen("file.txt" , "r");
	int entryPointer=0;
	int records=0;
   while ( 1 )
   {
	    c = fgetc ( fp ) ; // reading the file
		if ( c == EOF ){
			break ;
		}
    	else if (c == ','){
            records+=1;
            phoneBookNumber[entryPointer]='\0';
            //printf("%s %s",phoneBookNumber,phoneNumber);
            if(strcmp(phoneNumber,phoneBookNumber)==0){
                return records;
            }
    		entryPointer=0;
    		while(fgetc(fp) != '\n');
    	}
    	else
    	{
    		phoneBookNumber[entryPointer]=c;
			entryPointer+=1;
    	}
   }
   return -1;
}

int validate(int type, char value[]){
	// type == 0 => phone number check
	if(type==0){
		if(strlen(value)==10){
			for(int i=0;i<10;i++){
				if(!isdigit(value[i])){
					return -1;
				}
			}
		}
		else{
			return -1;
		}
		return 0;
	}
	// type == 1 => name check
	if(type==1){
        if(strlen(value)>40){
            return -1;
        }
		for(int i=0;i<strlen(value);i++){
			if(isdigit(value[i]))
				return -1;
		}
		return 0;
	}
	// type == 2 ==> Bill amount check
	if(type == 2){
		int point =0;
		for(int i=0;i<strlen(value);i++){
			if(value[i]=='.'){
				point+=1;
			}
			if(!isdigit(value[i]) && point > 1 ){
				return -1;
			}
		}
		return 0;
	}
}

void printAllRecord(){
	int numberOfRecord=0;
	char c;
	FILE *fp =fopen("file.txt" , "r");
	if ( fp == NULL )
	{
		printf ( "No Records availale!" ) ;
		return ;
	}
	while(1){
		c = fgetc ( fp ) ; // reading the file
		if ( c == '\n' ){
			numberOfRecord+=1;
		}
		if ( c == EOF ){
			break ;
		}
	}
	if(numberOfRecord<1){
		printf("No Records available!" );
		return;
	}
	fclose(fp);
	char Records[numberOfRecord][3][64];
	fp =fopen("file.txt" , "r");
	int variable=0, entryPointer=0, record=0;
   while ( 1 )
   {
	    c = fgetc ( fp ) ; // reading the file
		if ( c == EOF ){
			break ;
		}
    	else if (c == ','){
             Records[record][variable][entryPointer]='\0';
    		entryPointer=0;
    		variable+=1;
    	}
    	else if(c == '\n'){
            printf("\n");
        Records[record][variable][entryPointer]='\0';
    		record+=1;
    		variable=0;
    		entryPointer=0;
    	}
    	else
    	{
    		Records[record][variable][entryPointer]=c;
    		//printf("%c",Records[record][variable][entryPointer]);
			entryPointer+=1;


    	}

   }

   fclose ( fp ) ;
   printf("*********************************************************************************************************************************************\n");
   printf("* Phone Number                                  User Name                                     Amount                                        *\n");
   printf("*********************************************************************************************************************************************\n");
   for(int i=0;i<numberOfRecord;i++){
   	printf("* ");
   	for (int j = 0; j < 3; j++)
   	{
   		int k=0;
        printf("%s", Records[i][j]);
   		for (int l=k; l < 46-strlen(Records[i][j]); l++)
   		{
   			printf(" ");
   		}
   	}
   	printf("*\n");
   }
   printf("*********************************************************************************************************************************************\n");

}

void payment(){
    char phoneNumber[11];
    int record=0,linecount=0,validationResult=0;
    do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter 10 digit Phone Number for payment:");
		scanf("%s",&phoneNumber);
		validationResult+=1;
	}while(validate(0,phoneNumber));
    if((record = checkPreexistingRecord(phoneNumber))>0){
        int linecount=0;
        FILE *ft1 = fopen("file.txt" , "r");
        FILE *ft2 = fopen("tempo.txt" , "w");
        while(linecount != record-1){
            char ch= fgetc(ft1);
            if(ch == '\n'){
                linecount+=1;
            }
            fputc(ch, ft2);
        }
        char ch,name[64],index=0;
        while(fgetc(ft1) != ',');
        while((ch=fgetc(ft1)) != ','){
            name[index++]=ch;
        }
        name[index]='\0';
        while(fgetc(ft1) != '\n');
        fputs(phoneNumber, ft2);
        fputs(",",ft2);
        fputs(name, ft2);
        fputs(",",ft2);
        fputs("0.00", ft2);
        fputs("\n",ft2);
        ch = fgetc(ft1);
        while(ch != EOF){
            fputc(ch, ft2);
            ch= fgetc(ft1);
        }
        fclose(ft1);
        fclose(ft2);
        ft1 = fopen("file.txt" , "w");
        ft2 = fopen("tempo.txt" , "r");
        ch = fgetc(ft2);
        while(ch != EOF){
            fputc(ch, ft1);
            ch= fgetc(ft2);
        }
        fclose(ft1);
        fclose(ft2);
        printf("Your payment is Successful %s\nWe wish you all success! Thank you for using our services ",name);
        return ;
    }
    else{
        printf("No record found with that mobile number!\n\n Please check the entry!");
    }

}

void deleteRecord(){
char phoneNumber[11];
    int record=0,linecount=0,validationResult=0;
    do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter 10 digit Phone Number for deleting record:");
		scanf("%s",&phoneNumber);
		validationResult+=1;
	}while(validate(0,phoneNumber));
    if((record = checkPreexistingRecord(phoneNumber))>0){
        int linecount=0;
        FILE *ft1 = fopen("file.txt" , "r");
        FILE *ft2 = fopen("tempo.txt" , "w");
        while(linecount != record-1){
            char ch= fgetc(ft1);
            if(ch == '\n'){
                linecount+=1;
            }
            fputc(ch, ft2);
        }
        char ch;
        while(fgetc(ft1) != '\n');
        ch = fgetc(ft1);
        while(ch != EOF){
            fputc(ch, ft2);
            ch= fgetc(ft1);
        }
        fclose(ft1);
        fclose(ft2);
        ft1 = fopen("file.txt" , "w");
        ft2 = fopen("tempo.txt" , "r");
        ch = fgetc(ft2);
        while(ch != EOF){
            fputc(ch, ft1);
            ch= fgetc(ft2);
        }
        fclose(ft1);
        fclose(ft2);
        printf("Record is deleted Successful\n\nThank you for using our services!");
        return ;
    }
    else{
        printf("No record found with that mobile number!\n\n Please check the entry!");
    }
}
void search(){
    char phoneNumber[11];
    int record=0,linecount=0,validationResult=0;
    do{
		if(validationResult>0){
			printf("\n Enter the value in correct format!");
		}
		printf("\n\n\n Enter 10 digit Phone Number for Search:");
		scanf("%s",&phoneNumber);
		validationResult+=1;
	}while(validate(0,phoneNumber));

    char c;
	FILE *fp =fopen("file.txt" , "r");
	if ( fp == NULL )
	{
		return ;
	}
	char phoneBookNumber[11];
	int entryPointer=0;
	int records=0;
   while ( 1 )
   {
	    c = fgetc ( fp ) ; // reading the file
		if ( c == EOF ){
			break;
		}
    	else if (c == ','){
            records+=1;
            phoneBookNumber[entryPointer]='\0';
           // printf("%s %s",phoneBookNumber,phoneNumber);
            if(strcmp(phoneNumber,phoneBookNumber)==0){
                printf("Details\n\n");
                char ch,name[64],index=0,billAmount[64];
                while((ch=fgetc(fp)) != ','){
                    name[index++]=ch;
                }
                name[index]='\0';
                index=0;
                while((ch=fgetc(fp)) != '\n'){
                    billAmount[index++]=ch;
                }
                billAmount[index]='\0';
                printf("Phone Number: %s\n",phoneNumber);
                printf("Name: %s\n",name);
                printf("Bill Amount: %s\n",billAmount);
                return;
            }
    		entryPointer=0;
    		while(fgetc(fp) != '\n');
    	}
    	else
    	{
    		phoneBookNumber[entryPointer]=c;
			entryPointer+=1;
    	}
   }
   printf("No such record found");
   getch();

}
