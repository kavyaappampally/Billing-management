#include "billing.h"
#include <stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#include <ctype.h>

int main(){
char choice;



	system("cls");

	printf("\n\n\n\n\n\n\n\n\n\t\t****************************************************************");
	printf("\n\t\t------WELCOME TO THE TELECOM BILLING MANAGEMENT SYSTEM---");
	printf("\n\t\t****************************************************************");
	getch();
    system("cls");
	while (1)
	{
		system("cls");
		printf("\n Enter\n A : for adding new records.\n L : for list of records");
		printf("\n M : for modifying records.\n P : for payment");
		printf("\n S : for searching records.");
		printf("\n D : for deleting records.\n E : for exit\n");
		choice=getch();
		choice=toupper(choice);
		switch(choice)
		{
			case 'P':
				payment();break;
			case 'A':
				addRecord();break;
			case 'L':
				printAllRecord();break;
			case 'M':
				modifyRecord();break;
			case 'S':
				search();
				
				break;
			case 'D':
				deleteRecord();break;
			case 'E':
				system("cls");
				printf("\n\n\t\t\t\tTHANK YOU");
				printf("\n\n\n\n\n:\n\tFOR USING OUR SERVICE");
				exit(0);
				break;
			default:
				system("cls");
				printf("Incorrect Input");
				printf("\nAny key to continue");
				getch();
		}
		getch();
	}
}